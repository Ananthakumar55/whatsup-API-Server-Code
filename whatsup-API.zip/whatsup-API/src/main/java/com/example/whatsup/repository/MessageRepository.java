package com.example.whatsup.repository;
import com.example.whatsup.API.Message;
import org.springframework.data.jpa.repository.JpaRepository;


public interface MessageRepository extends JpaRepository<Message, Long> {
}


