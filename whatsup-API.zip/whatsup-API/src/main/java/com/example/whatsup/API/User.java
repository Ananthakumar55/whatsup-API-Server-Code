package com.example.whatsup.API;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.util.Set;
@Entity
public class User {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private String username;
	    private String fullName;
	    
	    public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
	        this.username = username;
	    }
	    
	    public String getFullName() {
	        return username;
	    }

	    public void setFullName(String username) {
	        this.username = username;
	    }

		public void setId(Long id2) {
			
			
		}

	
}	

	
	
	  

