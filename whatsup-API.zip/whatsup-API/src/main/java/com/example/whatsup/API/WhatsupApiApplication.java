package com.example.whatsup.API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhatsupApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhatsupApiApplication.class, args);
	}

}
