package com.example.whatsapp.service;

public class MessageService {

}
