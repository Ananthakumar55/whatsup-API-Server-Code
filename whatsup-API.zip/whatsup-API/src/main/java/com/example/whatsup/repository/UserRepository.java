

package com.example.whatsup.repository;

import com.example.whatsup.API.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
}